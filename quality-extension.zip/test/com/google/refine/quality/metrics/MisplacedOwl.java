package com.google.refine.quality.metrics;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.google.refine.quality.problems.QualityProblem;
import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.ModelFactory;
import com.hp.hpl.jena.rdf.model.StmtIterator;
import com.hp.hpl.jena.sparql.core.Quad;

public class MisplacedOwl {
  private static MisusedOwlDatatypeOrObjectProperties metric;
  private static List<Quad> quads = new ArrayList<Quad>();
  private static Class<?> cls;

  @BeforeClass
  public static void setUp() throws Exception {
//    cls = Class.forName((String.format("%s.%s", Constants.METRICS_PACKAGE,
//        "IncompatibleDatatypeRange")));
    metric = new MisusedOwlDatatypeOrObjectProperties();

    Model model = ModelFactory.createDefaultModel();
    // TODO temporal resource source.
    model.read("https://raw.githubusercontent.com/diachron/quality/luzzu-integration"
        + "/src/test/resources/testdumps/SampleInput_MisusedOwlDatatypeObjectProperty.ttl");
    
    // model.createResource("http://example.org/#obj1")
    // // .addLiteral(FOAF.knows,
    // ResourceFactory.createTypedLiteral("2012-03-11", XSDDatatype.XSDdate))
    // .addLiteral(RDFS.subPropertyOf,
    // ResourceFactory.createTypedLiteral("2012-03-11", XSDDatatype.XSDdate))
    // .addLiteral(RDFS.subPropertyOf,
    // ResourceFactory.createProperty("http://example.org/#property"))
    // .addLiteral(FOAF.birthday,
    // ResourceFactory.createTypedLiteral("2012-03-11", XSDDatatype.XSDdate))
    // .addLiteral(FOAF.birthday,
    // ResourceFactory.createTypedLiteral("2012-03-10", XSDDatatype.XSDstring));
    //
    StmtIterator si = model.listStatements();
    while (si.hasNext()) {
      quads.add(new Quad(null, si.next().asTriple()));
    }
  }

   @Test
  public void emptyQuads() throws IllegalAccessException, IllegalArgumentException,
      InvocationTargetException, NoSuchMethodException, SecurityException, InstantiationException {
//    metric.filterAllOwlProperties(quads);
    metric.compute(quads);

    
    List<QualityProblem> problems = metric.getQualityProblems();
   System.out.println(metric.metricValue());
    Assert.assertEquals(0.22, metric.metricValue(), 0.01);
  }

  @Test
  public void test() {
//    https://raw.githubusercontent.com/diachron/quality/luzzu-integration/src/test/resources/testdumps/SampleInput_MisusedOwlDatatypeObjectProperty.ttl
   
  }

}
