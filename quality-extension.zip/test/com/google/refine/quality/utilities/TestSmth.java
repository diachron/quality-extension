package com.google.refine.quality.utilities;

import static org.junit.Assert.*;

import java.beans.XMLDecoder;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONException;
import org.junit.Test;

import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.ModelFactory;
import com.hp.hpl.jena.rdf.model.Property;
import com.hp.hpl.jena.rdf.model.RDFNode;
import com.hp.hpl.jena.rdf.model.Resource;
import com.hp.hpl.jena.rdf.model.ResourceFactory;
import com.hp.hpl.jena.rdf.model.Statement;
import com.hp.hpl.jena.rdf.model.StmtIterator;
import com.hp.hpl.jena.sparql.core.Quad;

public class TestSmth {

  @Test
  public void test() throws IOException, ClassNotFoundException, JSONException {
    Writer writer = new StringWriter();
    writer.write("<html><head><title>come2niks.com</title></head><body>");
    //Adding the data to be displayed in body 
    writer.write("Name : <b>NIKHIL NAOGHARE</b>");
    writer.write("<br /><img src='imageSrc/image.jpg' />");
    //Closing the tags
    writer.write("</body></html>");
    writer.close();
  }


}
