package com.google.refine.quality.utilities;

import java.beans.XMLDecoder;
import java.beans.XMLEncoder;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONException;
import org.junit.Assert;
import org.junit.Test;

import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.ModelFactory;
import com.hp.hpl.jena.rdf.model.Property;
import com.hp.hpl.jena.rdf.model.RDFNode;
import com.hp.hpl.jena.rdf.model.Resource;
import com.hp.hpl.jena.rdf.model.ResourceFactory;
import com.hp.hpl.jena.rdf.model.Statement;
import com.hp.hpl.jena.rdf.model.StmtIterator;
import com.hp.hpl.jena.sparql.core.Quad;

public class ExportTest {

  @Test
  public void test() throws IOException, ClassNotFoundException, JSONException {
//    Model dst = ModelFactory.createDefaultModel();
//    Model src = JenaModelLoader
//        .getModel("https://raw.githubusercontent.com/diachron/quality/master/src/test"
//            + "/resources/testdumps/SampleInput_LabelsUsingCapitals.ttl");
//    List<Quad> quads = new ArrayList<Quad>();
//    StmtIterator si = src.listStatements();
//
//    while (si.hasNext()) {
//      Statement s = si.next();
//      quads.add(new Quad(null, s.asTriple()));
//    }
//    
//    dst.setNsPrefixes(src.getNsPrefixMap());
//     Map<String, String> prefix =  dst.getNsPrefixMap();
//     
//   
//   JSONArray serializations = new JSONArray();
//   serializations.put("TURTLE");
//   serializations.put("NT");
//   serializations.put("RDF/XML");
//   
//   for (int i = 0; i < serializations.length(); i++) {
//     String d = (String) serializations.get(i);
//   }
//
//    for (Quad quad : quads) {
//      Resource subject = ResourceFactory.createResource(quad.getSubject().toString());
//      Property predicate = ResourceFactory.createProperty(quad.getPredicate().toString());
//      RDFNode object = null;
//
//      String rawObject = quad.getObject().toString();
//      if (Utilities.isUrl(rawObject)) {
//        object = ResourceFactory.createResource(rawObject);
//      } else {
//        object = ResourceFactory
//          .createPlainLiteral(rawObject.substring(1, rawObject.length() - 1));
//      }
//      Statement statement = ResourceFactory.createStatement(subject, predicate, object);
//      dst.add(statement);
//    }
//    src.write(System.out);
//    System.out.println("\n");
//    dst.write(System.out);
//    Writer writer1 = new StringWriter();
////    Writer writer2.
//    dst.write(writer1);
  }
}
