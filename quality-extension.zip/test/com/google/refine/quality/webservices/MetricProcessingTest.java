package com.google.refine.quality.webservices;

import org.junit.Test;

public class MetricProcessingTest {

  @Test
  public void test() {
//    fail("Not yet implemented");
  }

}
