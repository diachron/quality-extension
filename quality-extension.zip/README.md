## Quality-extension
[![Build Status](https://travis-ci.org/diachron/quality-extension.svg?branch=master)](https://travis-ci.org/diachron/quality-extension)

Extension for OpenRefine im context of Task 3.3 (Data cleaning ) WP3
